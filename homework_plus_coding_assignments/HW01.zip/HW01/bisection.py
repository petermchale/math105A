def different_sign(a, b):
    return a * b < 0.0

def bisection(func, low, high, n_max):
    assert different_sign(func(low), func(high))

    for i in range(n_max):
        midpoint = (low + high) / 2.0
        if different_sign(func(low), func(midpoint)):
            high = midpoint
        else:
            low = midpoint

    return midpoint
